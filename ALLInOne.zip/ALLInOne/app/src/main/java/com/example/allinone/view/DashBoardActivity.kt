package com.example.allinone.view

import android.os.Bundle
import android.view.LayoutInflater
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.Fragment
import com.example.allinone.R
import com.example.allinone.databinding.ActivityDashBoardBinding

class DashBoardActivity : AppCompatActivity() {


    private lateinit var binding: ActivityDashBoardBinding


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityDashBoardBinding.inflate(LayoutInflater.from(this))
        setContentView(binding.root)


        binding.bottomNavigationView.setOnItemSelectedListener { item ->
            val selectedFragment: Fragment? = when (item.itemId) {
                R.id.home -> DashBoardFragment()
                R.id.my_trips -> DashBoardFragment()
                R.id.holder -> DashBoardFragment()
                R.id.manifests -> DashBoardFragment()
                R.id.accounts -> DashBoardFragment()
                else -> null
            }
            if (selectedFragment != null) {
                openPage(selectedFragment)
            }
            true
        }

        val dashboardFragment = DashBoardFragment()
        openPage(dashboardFragment)


    }

    private fun openPage(fragment: Fragment) {
        val fm = supportFragmentManager
        val fragmentTransaction = fm.beginTransaction()
        fragmentTransaction.replace(R.id.view_pager, fragment, "")
        fragmentTransaction.addToBackStack(null)
        fragmentTransaction.commit()
    }

}
package com.example.allinone.adapter

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.bumptech.glide.load.resource.bitmap.CircleCrop
import com.example.allinone.R
import com.example.allinone.model.Product

class ProductAdapter(private var products: List<Product>) :
    RecyclerView.Adapter<ProductAdapter.ViewHolder>() {

    inner class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {

        val categoryImageView: ImageView = itemView.findViewById(R.id.product_img)
        val expressValue: ImageView = itemView.findViewById(R.id.express_value)
        val productName: TextView = itemView.findViewById(R.id.product_name)
        val offerPrice: TextView = itemView.findViewById(R.id.offer_price)
        val actualPrice: TextView = itemView.findViewById(R.id.actual_price)
        val offerTag: TextView = itemView.findViewById(R.id.productOfferTag)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view =
            LayoutInflater.from(parent.context).inflate(R.layout.list_products, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val products = products[position]
        holder.productName.text = products.name
        holder.offerPrice.text = products.offer_price
        holder.actualPrice.text = products.actual_price
        if (products.is_express) {
            holder.expressValue.visibility = View.VISIBLE // To make it visible
        } else {
            holder.expressValue.visibility = View.GONE // To hide and remove from layout
        }

        holder.offerTag.text = products.offer.toString() + " % OFF"
        Glide.with(holder.categoryImageView)
            .load(products.image)
            .transform(CircleCrop())
            .into(holder.categoryImageView)
    }

    override fun getItemCount(): Int {
        return products.size
    }


    fun setData(newCategories: List<Product>) {
        products = newCategories
        notifyDataSetChanged()
    }
}
package com.example.allinone.view

import android.annotation.SuppressLint
import android.content.ContentValues
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.allinone.adapter.BannerAdapter
import com.example.allinone.adapter.CategoryAdapter
import com.example.allinone.adapter.ProductAdapter
import com.example.allinone.databinding.FragmentDashBoardBinding
import com.example.allinone.model.Banner
import com.example.allinone.model.Category
import com.example.allinone.model.Product
import com.example.allinone.offline.MyDatabaseHelper
import com.example.allinone.repository.MyRepository
import com.example.allinone.viewModel.MyViewModel
import com.example.allinone.viewModel.MyViewModelFactory
import com.google.gson.Gson
import kotlinx.coroutines.runBlocking

class DashBoardFragment : Fragment() {

    private lateinit var binding: FragmentDashBoardBinding
    private lateinit var categoryAdapter: CategoryAdapter
    private lateinit var bannerAdapter: BannerAdapter
    private lateinit var productAdapter: ProductAdapter
    private lateinit var viewModel: MyViewModel

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        binding = FragmentDashBoardBinding.inflate(inflater, container, false)
        val view = binding.root

        setupCategoryRecyclerView()
        setupBannerRecyclerView()
        setupProductRecyclerView()

        val repository = MyRepository()
        viewModel = ViewModelProvider(this, MyViewModelFactory(repository)).get(MyViewModel::class.java)

        // Fetch data from API
        fetchData()
      //  loadOfflineData()

        return view
    }

    private fun setupCategoryRecyclerView() {
        categoryAdapter = CategoryAdapter(emptyList())
        binding.category.apply {
            layoutManager = LinearLayoutManager(requireContext(), LinearLayoutManager.HORIZONTAL, false)
            adapter = categoryAdapter
        }
    }

    private fun setupBannerRecyclerView() {
        bannerAdapter = BannerAdapter(emptyList())
        binding.banner.apply {
            layoutManager = LinearLayoutManager(requireContext(), LinearLayoutManager.HORIZONTAL, false)
            adapter = bannerAdapter
        }
    }

    private fun setupProductRecyclerView() {
        productAdapter = ProductAdapter(emptyList())
        binding.products.apply {
            layoutManager = LinearLayoutManager(requireContext(), LinearLayoutManager.HORIZONTAL, false)
            adapter = productAdapter
        }
    }

    private fun fetchData() {
        runBlocking {
            val data = viewModel.fetchDataFromApi()

            Log.d("Response", data.toString())

            if (data != null) {
                val gson = Gson()
                //val homeDataResponse = gson.fromJson(data.toString(), HomeData::class.java)

                val dbHelper = MyDatabaseHelper(requireContext())
                val db = dbHelper.writableDatabase

                val categoryList = data.homeData
                    .filter { it.type == "category" }
                    .flatMap { it.values }
                    .map { gson.fromJson(gson.toJson(it), Category::class.java) }

                for (category in categoryList) {
                    val values = ContentValues().apply {
                        put(MyDatabaseHelper.CategoryTable.COLUMN_NAME, category.name)
                    }
                    db.insert(MyDatabaseHelper.CategoryTable.TABLE_NAME, null, values)
                }

                val bannerList = data.homeData
                    .filter { it.type == "banners" }
                    .flatMap { it.values }
                    .map { gson.fromJson(gson.toJson(it), Banner::class.java) }

                val productList = data.homeData
                    .filter { it.type == "products" }
                    .flatMap { it.values }
                    .map { gson.fromJson(gson.toJson(it), Product::class.java) }
                Log.d("categories", categoryList.toString())
                //Log.d("banners", banners.toString())
                //Log.d("products", products.toString())

                categoryAdapter.setData(categoryList)
                bannerAdapter.setData(bannerList)
                productAdapter.setData(productList)
            } else {
                // Handle the case when data is null or there's an error
            }
        }
    }

    @SuppressLint("Range")
    private fun loadOfflineData() {
        val dbHelper = MyDatabaseHelper(requireContext())
        val db = dbHelper.readableDatabase

        val categoryList = mutableListOf<Category>()
        val cursor = db.query(
            MyDatabaseHelper.CategoryTable.TABLE_NAME,
            null,
            null,
            null,
            null,
            null,
            null
        )

        cursor?.use {
            while (cursor.moveToNext()) {
                val columnIndexId = cursor.getColumnIndex(MyDatabaseHelper.CategoryTable.COLUMN_ID)
                val columnIndexName = cursor.getColumnIndex(MyDatabaseHelper.CategoryTable.COLUMN_NAME)
                val columnIndexImage = cursor.getColumnIndex(MyDatabaseHelper.CategoryTable.COLUMN_IMAGE)

                val id = cursor.getLong(columnIndexId)
                val name = cursor.getString(columnIndexName)
                val image = if (columnIndexImage != -1) {
                    cursor.getString(columnIndexImage)
                } else {
                    // Handle the case where the COLUMN_IMAGE does not exist in the cursor
                    ""
                }

                val category = Category(id, name, image)
                categoryList.add(category)
            }
        }

        db.close()

        // Set the data in your adapters (categoryAdapter, bannerAdapter, productAdapter)
        categoryAdapter.setData(categoryList)
    }
}
package com.example.allinone.offline

import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

class MyDatabaseHelper(context: Context) : SQLiteOpenHelper(context, DATABASE_NAME, null, DATABASE_VERSION) {

    companion object {
        private const val DATABASE_NAME = "offlineDatabase.db"
        private const val DATABASE_VERSION = 1
    }

    override fun onCreate(db: SQLiteDatabase?) {
        // Create tables and define their schema here
        db?.execSQL(CategoryTable.CREATE_TABLE) // Call the CREATE_TABLE statement for categories
        db?.execSQL("CREATE TABLE IF NOT EXISTS products (id INTEGER PRIMARY KEY, name TEXT, price REAL)")
    }

    override fun onUpgrade(db: SQLiteDatabase?, oldVersion: Int, newVersion: Int) {
        // Handle database schema upgrades here
        db?.execSQL("DROP TABLE IF EXISTS ${CategoryTable.TABLE_NAME}")
        db?.execSQL("DROP TABLE IF EXISTS products")
        onCreate(db)
    }

    object CategoryTable {
        const val TABLE_NAME = "categories"
        const val COLUMN_ID = "_id"
        const val COLUMN_NAME = "name"
        const val COLUMN_IMAGE = "img"

        const val CREATE_TABLE = """
        CREATE TABLE IF NOT EXISTS $TABLE_NAME (
            $COLUMN_ID INTEGER PRIMARY KEY AUTOINCREMENT,
            $COLUMN_NAME TEXT,
            $COLUMN_IMAGE TEXT
        )
    """
    }
}

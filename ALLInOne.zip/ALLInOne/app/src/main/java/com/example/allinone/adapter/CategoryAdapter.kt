package com.example.allinone.adapter

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.bumptech.glide.load.resource.bitmap.CircleCrop
import com.example.allinone.R
import com.example.allinone.model.Category


class CategoryAdapter(private var categories: List<Category>) :
    RecyclerView.Adapter<CategoryAdapter.ViewHolder>() {

    inner class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val categoryImageView: ImageView = itemView.findViewById(R.id.category_image)
        val categoryNameTextView: TextView = itemView.findViewById(R.id.category_name)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.list_items, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val category = categories[position]
        val randomBackgroundColors = arrayOf(
            R.color.blue,
            R.color.dark_green,
            R.color.orange
        )
        val randomIndex = (randomBackgroundColors.indices).random()
        val randomColorResource = randomBackgroundColors[randomIndex]
        holder.categoryImageView.setBackgroundResource(randomColorResource)


        holder.categoryNameTextView.text = category.name
        Glide.with(holder.categoryImageView)
            .load(category.image_url)
            .transform(CircleCrop())
            .into(holder.categoryImageView)
    }

    override fun getItemCount(): Int {
        return categories.size
    }

    fun setData(newCategories: List<Category>) {
        categories = newCategories
        notifyDataSetChanged()
    }
}

package com.example.allinone.model

import com.google.gson.annotations.SerializedName


data class ProductModel(
    @SerializedName("status") val status: Boolean,
    @SerializedName("homeData") val homeData: List<HomeData>
)

data class HomeData(
    @SerializedName("type") val type: String,
    @SerializedName("values") val values: List<Any>

)

data class Category(
    val id: Long,
    val name: String,
    val image_url: String
)

data class Banner(
    val id: Int,
    val banner_url: String
)

data class Product(
    val id: Int,
    val name: String,
    val image: String,
    val actual_price: String,
    val offer_price: String,
    val offer: Int,
    val is_express: Boolean
)

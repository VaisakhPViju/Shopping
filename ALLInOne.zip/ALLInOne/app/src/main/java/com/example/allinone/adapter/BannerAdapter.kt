package com.example.allinone.adapter

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.bumptech.glide.load.resource.bitmap.CircleCrop
import com.example.allinone.R
import com.example.allinone.model.Banner


class BannerAdapter(private var banners: List<Banner>) :
    RecyclerView.Adapter<BannerAdapter.ViewHolder>() {

    inner class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val bannerImg: ImageView = itemView.findViewById(R.id.banner_img)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.list_banner, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val banner = banners[position]
        Glide.with(holder.bannerImg)
            .load(banner.banner_url)
            .into(holder.bannerImg)
    }

    override fun getItemCount(): Int {
        return banners.size
    }

    fun setData(newCategories: List<Banner>) {
        banners = newCategories
        notifyDataSetChanged()
    }
}
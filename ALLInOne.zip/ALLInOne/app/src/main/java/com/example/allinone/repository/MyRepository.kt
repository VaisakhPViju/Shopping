package com.example.allinone.repository

import android.util.Log
import com.example.allinone.model.ProductModel
import com.google.gson.Gson
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request

class MyRepository {

    suspend fun fetchDataFromApi(): ProductModel? {
        return withContext(Dispatchers.IO) {
            try {
                val client = OkHttpClient()
                val request = Request.Builder()
                    .url("https://run.mocky.io/v3/69ad3ec2-f663-453c-868b-513402e515f0")
                    .build()

                val response = client.newCall(request).execute()
                val responseData = response.body?.string()

                if (responseData != null) {
                    // Log the API response
                    Log.d("API Response", responseData)

                    // Use Gson to parse the JSON response into a HomeData object
                    val gson = Gson()
                    gson.fromJson(responseData, ProductModel::class.java)
                } else {
                    null
                }
            } catch (e: Exception) {
                null // Handle exceptions (e.g., network errors) gracefully
            }
        }
    }
}

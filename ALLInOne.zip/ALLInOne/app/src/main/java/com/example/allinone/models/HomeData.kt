package com.example.example

import com.google.gson.annotations.SerializedName


data class HomeData (

  @SerializedName("type"   ) var type   : String?           = null,
  @SerializedName("values" ) var values : ArrayList<Values> = arrayListOf()

)
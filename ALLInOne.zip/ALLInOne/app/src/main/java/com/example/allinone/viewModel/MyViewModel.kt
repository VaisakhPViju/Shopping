package com.example.allinone.viewModel

import androidx.lifecycle.ViewModel
import com.example.allinone.model.ProductModel
import com.example.allinone.repository.MyRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class MyViewModel(private val repository: MyRepository) : ViewModel() {

    suspend fun fetchDataFromApi(): ProductModel? {
        return withContext(Dispatchers.IO) {
            repository.fetchDataFromApi()
        }
    }
}
package com.example.example

import com.google.gson.annotations.SerializedName


data class ProductModel (

  @SerializedName("status"   ) var status   : Boolean?            = null,
  @SerializedName("homeData" ) var homeData : ArrayList<HomeData> = arrayListOf()

)